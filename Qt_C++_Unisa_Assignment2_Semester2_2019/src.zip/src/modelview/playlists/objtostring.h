#ifndef OBJTOSTRING_H
#define OBJTOSTRING_H
#include <QString>
class QObject;


QString objToString(const QObject* obj);

#endif        //  #ifndef OBJTOSTRING_H
