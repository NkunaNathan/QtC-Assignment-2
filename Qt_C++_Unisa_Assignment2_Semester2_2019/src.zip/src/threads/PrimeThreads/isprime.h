#ifndef ISPRIME_H
#define ISPRIME_H
#include <qglobal.h>

bool isPrime(int value);

#endif // ISPRIME_H
