#include <string>
using namespace std;
//start
struct Fraction {
    int numer, denom;
    string description;
};
//end

void printFraction(Fraction f);



