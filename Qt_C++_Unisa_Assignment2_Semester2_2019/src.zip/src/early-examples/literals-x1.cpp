#include <iostream>
using namespace std;

int main() {
    cout << " GNU stands for \"GNU\'s Not Unix\"." << endl;
    return 0;
}

/*out
OOP> g++ -Wall literals.cc
OOP> a.out
 GNU stands for "GNU's Not Unix". 
OOP>
*/
