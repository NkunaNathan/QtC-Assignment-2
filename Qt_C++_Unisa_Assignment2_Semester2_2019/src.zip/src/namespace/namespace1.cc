#include "a.h"
#include "b.h"

int main() {
    A::f();
    B::g();
}
/*OUT
f from A
g from B
*/
