namespace {
    const int MAXSIZE = 256;
}

void f1() {
    int s[MAXSIZE];
}