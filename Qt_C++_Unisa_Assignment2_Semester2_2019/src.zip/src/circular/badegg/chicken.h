#ifndef CHICKEN_H
#define CHICKEN_H

//class Egg;
//start
#include "egg.h"

class Chicken {
 public:
    Egg* layEgg();
};
//end

#endif        //  #ifndef CHICKEN_H
