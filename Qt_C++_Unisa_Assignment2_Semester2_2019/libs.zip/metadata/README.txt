This library contains common base classes for for MetaData applications
such as media jukebox apps. 

It has no actual metadata loading or saving capability by itself, for that you need
either Phonon, QtMultiMediaKit or TagLib.

A taglib implementation is in ../filetagger
A mobility version is in ../mobilitymetadata
A phonon version is in ../phononmetadata.
