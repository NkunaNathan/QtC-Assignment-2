#include <QObject>
#include <QtTest>

/**
  Test Case for Preference Class
  */

class TestPreference : public QObject {
    Q_OBJECT
    
private slots:
    virtual void testPreference() ;
};
