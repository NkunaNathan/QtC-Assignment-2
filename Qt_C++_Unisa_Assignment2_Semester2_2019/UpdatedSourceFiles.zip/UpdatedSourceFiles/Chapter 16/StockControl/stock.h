#ifndef STOCK_H
#define STOCK_H

#include <QString>
#include <QObject>

class Stock : public QObject
{
    Q_OBJECT
public:
    Q_PROPERTY(QString item READ getItem WRITE setItem);
    Q_PROPERTY(int quantity READ getQuantity WRITE setQuantity);

    explicit Q_INVOKABLE Stock();
    Stock(QString item, int quantity);

    QString getItem() const;
    int getQuantity() const;

    void setItem(QString i);
    void setQuantity(int q);

    QString toString() const;

protected:
    QString item;
    int quantity;
};

#endif // STOCK_H
