#include <QDebug>
#include <QObject>
#include <QMetaObject>

#include "stockobjectfactory.h"
//#include "address.h"
//#include "country.h"
#include "stock.h"

//start id=newobject
StockObjectFactory::StockObjectFactory() {
    //m_knownClasses["UsAddress"] = UsAddress::staticMetaObject;
    //m_knownClasses["CanadaAddress"] = CanadaAddress::staticMetaObject;
    m_knownClasses["Stock"] = Stock::staticMetaObject;
}

QObject* StockObjectFactory::newObject(QString className, QObject* parent) {
    QObject* retval = 0;
    if (m_knownClasses.contains(className)) {
        const QMetaObject& mo = m_knownClasses[className];
        retval = mo.newInstance();      /* Requires Qt 4.5 or later. */
        //qDebug() << "newInstance created";
        if (retval == 0) {
            qDebug() << "Error creating " << className;
            abort();
        }
    } else {
        qDebug() << QString("Generic QObject created for new %1")
                    .arg(className);
        retval = new QObject();
        //retval->setProperty("className", className);
    }
    if (parent != 0) retval->setParent(parent);
    return retval;
}
//end


