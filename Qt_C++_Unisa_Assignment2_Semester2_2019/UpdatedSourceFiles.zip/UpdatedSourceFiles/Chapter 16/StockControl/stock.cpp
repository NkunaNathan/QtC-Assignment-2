#include "Stock.h"

Stock::Stock()
{
    item = "";
    quantity = 0;
}

Stock::Stock(QString i, int q) : item(i), quantity(q)
{}

QString Stock::getItem() const
{
    return item;
}

int Stock::getQuantity() const
{
    return quantity;
}

void Stock::setItem(QString i)
{
    item = i;
}

void Stock::setQuantity(int q)
{
    quantity = q;
}

QString Stock::toString() const
{
    return "Stock: " + item + ", " + QString::number(quantity,10);
}
