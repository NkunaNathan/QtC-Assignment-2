#include <QtCore/QCoreApplication>
#include "stock.h"
#include "qobjectwriter.h"
#include "qobjectreader.h"
#include "stockobjectfactory.h"

#include <QList>
#include <QStringList>
#include <QFile>
#include <QTextStream>

QTextStream cout(stdout);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // create some Stock items
    Stock* s1 = new Stock("Kit Kat", 12);
    Stock* s2 = new Stock("Bar One", 56);
    Stock* s3 = new Stock("The Star", 100);

    // add them to a list
    QList<Stock*> myStock;
    myStock.append(s1);
    myStock.append(s2);
    myStock.append(s3);

    // create a QObjectWriter instance and use it to get the XML code and write it to file
    QObjectWriter qow;

    QFile fileStock("stocklist.xml");
    fileStock.open(QIODevice::WriteOnly);
    QTextStream toFile(&fileStock);

    toFile << "<list>" << endl; // create a root tag for the XML file
    for (int i=0; i<myStock.size(); i++)
    {
        cout << qow.toString(myStock.at(i));  // just to check was is being written
        toFile << qow.toString(myStock.at(i));
    }
    toFile << "</list>" << endl; // close the root tag for the XML file

    fileStock.close();
    cout << endl;

    // read the data in again
    cout << "Reading the data in again" << endl;
    StockObjectFactory* objFact = new StockObjectFactory();
    fileStock.open(QIODevice::ReadOnly);
    QObjectReader qor("stocklist.xml", objFact);

    Stock* sp = static_cast<Stock*>(qor.getRoot());
    while (sp != 0)
    {
        cout << sp->toString() << endl;
        sp = static_cast<Stock*>(qor.getRoot());
    }

    return a.exec();
}
