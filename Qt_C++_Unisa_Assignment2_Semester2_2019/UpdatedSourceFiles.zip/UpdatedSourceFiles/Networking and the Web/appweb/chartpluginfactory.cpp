#include "chartpluginfactory.h"
#include "piechart.h"

ChartPluginFactory::ChartPluginFactory()
{
}

QList<QWebPluginFactory::Plugin> ChartPluginFactory::plugins() const
{
    QWebPluginFactory::Plugin chart;
    chart.name = QString("application/x-chart");
    chart.description = QString("Draws a pie chart");
    QList<QWebPluginFactory::Plugin> list;
    list.append(chart);
    return list;
}

QObject* ChartPluginFactory::create(const QString &mimeType,
       const QUrl &,
       const QStringList &argumentNames,
       const QStringList &argumentValues) const
{
    if (mimeType == "application/x-chart")
    {
        // add code here
    }
    else
        return 0;
}
