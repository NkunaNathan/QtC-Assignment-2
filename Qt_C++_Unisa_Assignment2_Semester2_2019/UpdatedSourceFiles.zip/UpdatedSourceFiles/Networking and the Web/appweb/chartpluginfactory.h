#ifndef CHARTPLUGINFACTORY_H
#define CHARTPLUGINFACTORY_H

#include <QWebPluginFactory>

class ChartPluginFactory : public QWebPluginFactory
{
public:
    ChartPluginFactory();
    QList<QWebPluginFactory::Plugin> plugins() const;
    QObject* create(const QString &mimeType,
           const QUrl &,
           const QStringList &argumentNames,
           const QStringList &argumentValues) const;
};

#endif // CHARTPLUGINFACTORY_H
