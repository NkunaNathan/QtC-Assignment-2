#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets>
#include <QCalendarWidget>
#include <QMap>
#include <QWebElement>
#include <QWebFrame>
//#include <QVBoxLayout>
//#include <QHBoxLayout>

class QWebView;
class QMenu;
class QAction;
class QMenuBar;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void loadFile();
    void changeFile();
    void dateSelected();

private:
    QWidget* widget;
    QCalendarWidget* cal;
    QWebView* webView;
    QMenuBar* menuBar;
    QMenu* file;
    QAction* load;
    QMap<QDate, QWebElement> dateElement;
    QWebElement currentReport;
};

#endif // MAINWINDOW_H
