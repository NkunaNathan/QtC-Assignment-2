#ifndef PIECHART_H
#define PIECHART_H

#include <QWidget>

class PieChart : public QWidget
{
    Q_OBJECT
public:
    explicit PieChart(QWidget *parent = 0);
    void setTitle(QString t);
    void setValue(int v);
    QString getTitle() const;
    int getValue() const;
    void paintEvent(QPaintEvent *);
signals:

public slots:

private:
    QString title;
    int value;
};

#endif // PIECHART_H
