#include "piechart.h"
#include <QPainter>

PieChart::PieChart(QWidget *parent) :
    QWidget(parent)
{
}

void PieChart::setTitle(QString t)
{
    title = t;
    repaint();
}

void PieChart::setValue(int v)
{
    value = v;
    repaint();
}

QString PieChart::getTitle() const
{
    return title;
}

int PieChart::getValue() const
{
    return value;
}

void PieChart::paintEvent(QPaintEvent *)
 {
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setPen(QPen(Qt::blue, 2, Qt::SolidLine, Qt::RoundCap, Qt::MiterJoin));
    painter.setBrush(QBrush(Qt::white, Qt::SolidPattern));
    painter.drawEllipse(25, 25, 100, 100);
    painter.setPen(QPen(Qt::green, 2, Qt::SolidLine, Qt::RoundCap, Qt::MiterJoin));
    painter.setBrush(QBrush(Qt::green, Qt::SolidPattern));
    painter.drawPie(27, 27, 96, 96, 90*16, -value/100.0*360*16);
    painter.setPen(QPen(Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::MiterJoin));
    painter.setFont(QFont("Arial", 10));
    QFontMetrics fm = painter.fontMetrics();
    int wide = fm.width(title);
    int x = (100-wide)/2;
    painter.drawText(25+x, 14, title);
 }
