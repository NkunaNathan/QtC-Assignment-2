#include "mainwindow.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QWebView>
#include <QMenu>
#include <QMenuBar>
#include <QAction>
#include <QUrl>
#include <QWebElementCollection>
#include <QTextCharFormat>
#include <QMessageBox>
#include <QScriptEngine>
#include "chartpluginfactory.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    widget = new QWidget;
    setCentralWidget(widget);

    menuBar = new QMenuBar;
    file = new QMenu("&File", this);
    load = file->addAction("&Load");
    menuBar->addMenu(file);
    //connect() triggered() signal to loadFile() slot

    QHBoxLayout* layout = new QHBoxLayout;
    cal = new QCalendarWidget(this);
    cal->setSelectionMode(QCalendarWidget::NoSelection);
    webView = new QWebView(this);
    layout->addWidget(cal);
    layout->addWidget(webView);

    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->setMenuBar(menuBar);
    mainLayout->addLayout(layout);
    widget->setLayout(mainLayout);
    setWindowTitle("Report");

    // set the plugin factory here
}

MainWindow::~MainWindow()
{
}

void MainWindow::loadFile()
{
    QUrl page = QUrl::fromLocalFile("C:\\COS3711\\myweb.html"); //change this to point to where your file is saved
    webView->load(page);
    // connect the webView's loadFinished(bool) signal to the changeFile() slot
    // set PluginsEnabled here
}

void MainWindow::changeFile()
{
    QTextCharFormat highlight;
    highlight.clearBackground();
    dateElement.clear();
    QMap<QDate, QTextCharFormat> changed = cal->dateTextFormat();
    QMapIterator<QDate, QTextCharFormat> i(changed);
    while (i.hasNext())
    {
        i.next();
        cal->setDateTextFormat(i.key(), highlight);
    }

    QWebFrame* frame = webView->page()->mainFrame();
    // place addToJavaScriptWindowObject call here
    QWebElementCollection divReports = frame->findAllElements("div.report");
    foreach (QWebElement report, divReports)
    {
        QString id = report.attribute("id");
        QRegExp dateRegEx("report_(\\d+)_(\\d{1,2})_([0-9]{1,2})");
        if(!dateRegEx.exactMatch(id))
            continue;
        QDate date(2000+dateRegEx.cap(3).toInt(), dateRegEx.cap(2).toInt(), dateRegEx.cap(1).toInt());
        dateElement.insert(date, report);
        report.findFirst("div.reportcontent").setStyleProperty("display", "none");
        highlight.setBackground(Qt::red);
        cal->setDateTextFormat(date, highlight);
        cal->setSelectionMode(QCalendarWidget::SingleSelection);
    }
    // connect the calendar's selectionChanged() signal to the dateSelected() slot
}

void MainWindow::dateSelected()
{
    // add code here
}
