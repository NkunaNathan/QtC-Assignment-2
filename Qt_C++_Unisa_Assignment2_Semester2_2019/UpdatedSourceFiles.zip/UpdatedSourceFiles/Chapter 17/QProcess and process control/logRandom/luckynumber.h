#ifndef LUCKYNUMBER_H
#define LUCKYNUMBER_H

#include <QProcess>

class LuckyNumber : public QProcess {
    Q_OBJECT
  public:
    LuckyNumber();
    ~LuckyNumber();
  public slots:
    void logOutput();
private:
    QProcess p;
};
//end

#endif

