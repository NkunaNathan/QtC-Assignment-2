#include "luckynumber.h"
#include <QTextStream>

LuckyNumber::LuckyNumber() {
    connect (&p, SIGNAL(readyReadStandardOutput()),this, SLOT(logOutput()));
    p.start("randomNumbers");
}

LuckyNumber::~LuckyNumber() {
    terminate();
}

void LuckyNumber::logOutput() {
    QTextStream cout(stdout, QIODevice::WriteOnly);    
    QByteArray bytes = p.readAllStandardOutput();
    cout<< QString(bytes);
}
