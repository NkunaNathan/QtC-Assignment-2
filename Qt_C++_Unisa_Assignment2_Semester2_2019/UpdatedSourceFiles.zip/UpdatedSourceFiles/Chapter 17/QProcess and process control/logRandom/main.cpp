#include <QtCore/QCoreApplication>
#include "luckynumber.h"

int main (int argc, char* argv[]) {
    QCoreApplication a(argc, argv);
    LuckyNumber ln;
    return a.exec();
}


