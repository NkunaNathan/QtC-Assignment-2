#include <stdlib.h>
#include <time.h>
#include <QTextStream>

int main (int argc, char* argv[]) {

    srand(time(0));
    int number = 1;
    QTextStream cout(stdout, QIODevice::WriteOnly);

    while(number <=10)
    {
        int randomNumber = rand()% 100;
        cout << randomNumber <<"\n";
        number = number + 1;
    }
    return 0;
}
